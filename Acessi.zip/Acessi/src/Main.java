import Entidades.Metro.Estacao;
import Entidades.Metro.Linha;
import Entidades.Metro.Viagem;
import Entidades.Pessoa.Funcionario;
import Entidades.Pessoa.GerenciadorDeUsuario;
import Entidades.Pessoa.Passageiro;
import Entidades.Pessoa.Usuario;
import Entidades.Problema.Alerta;
import Entidades.Problema.Feed;
import Entidades.Problema.Notificacao;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class Main {
    public static void main(String[] args) {
        //Feed
        Feed feed = new Feed(new ArrayList<Notificacao>(), new ArrayList<Alerta>());


        //Gerenciador de Usuários
        GerenciadorDeUsuario gerenciador = new GerenciadorDeUsuario(new ArrayList<Usuario>());

        //Passageiros
        Passageiro passageiro1 = new Passageiro(1, "Alice", "alice@gmail.com", "senha123", "Passageiro",1, feed.getNotificacoesOrdenadasPorData());
        Passageiro passageiro2 = new Passageiro(2, "Bob", "bob@gmail.com", "senha456", "Passageiro", 2, feed.getNotificacoesOrdenadasPorData());

        //Funcionários
        Funcionario funcionario1 = new Funcionario(3, "Carol", "carol@gmail", "senha789", "Funcionário", 3,"Segurança", feed.getAlertas());
        Funcionario funcionario2 = new Funcionario(4, "Luiza", "luiza@gmail", "senha012", "Funcionário", 4, "Administrador", feed.getAlertas());

        //Linhas
        Linha linhaAmarela = new Linha("Linha 4-Amarela", LocalTime.now(), LocalTime.now(), "Amarela", "4", new ArrayList<Estacao>());
        Linha linhaEsmeralda = new Linha("Linha 9-Esmeralda", LocalTime.now(), LocalTime.now(), "Esmeralda", "9", new ArrayList<Estacao>());

        //Estações
        Estacao estacaoLuz = new Estacao("Estação Luz", 40000, 10300, "Praça da Luz, 1, Luz, São Paulo - SP");
        Estacao estacaoRepublica = new Estacao("Estação República", 40000, 10760, "Praça da República, 299 - República, São Paulo - SP, 01045-001");
        Estacao estacaoHigienopolis = new Estacao("Estação Higienópolis-Mackenzie", 40000, 8950, "Higienópolis-Mackenzie, R. da Consolação - Consolação, São Paulo - SP, 01220-010");
        Estacao estacaoPaulista = new Estacao("Estação Paulista", 40000, 30746, "Estação Paulista do Metro - Consolação, São Paulo - SP, 01301-100");
        Estacao estacaoOscarFreire = new Estacao("Estação Oscar Freire", 40000, 15687, "Oscar Freire, Av. Rebouças, 1089 - Cerqueira César, São Paulo - SP, 05401-150");
        Estacao estacaoFradiqueCoutinho = new Estacao("Estação Fradique Coutinho", 40000, 23365, "Fradique Coutinho, R. dos Pinheiros, 623 - Pinheiros, São Paulo - SP, 05422-011");
        Estacao estacaoFariaLima = new Estacao("Estação Faria Lima", 40000, 16758, "Faria Lima - Pinheiros, São Paulo - SP, 05421-090");
        Estacao estacaoPinheiros = new Estacao("Estação Pinheiros", 40000, 22840, "Pinheiros, R. Capri, 145 - Pinheiros, São Paulo - SP, 05425-030");
        Estacao estacaoButanta = new Estacao("Estação Butantã", 40000, 17329, "Butantã, São Paulo - SP, 05503-001");
        Estacao estacaoMorumbi = new Estacao("Estação São Paulo-Morumbi", 40000, 6078, "Estação Morumbi de metrô linha amarela, Av. Dep. Jacob Salvador Zveibil, 50 - Vila Progredior, São Paulo - SP, 03178-200");
        Estacao estacaoVilaSonia = new Estacao("Estação Vila Sônia", 40000, 19087, "Vila Sônia-Professora Elisabeth Tenreiro - Ferreira, São Paulo - SP");
        Estacao estacaoVilaOlimpia = new Estacao("Estação Vila-Olímpia", 40000, 19787, "Marginal Pinheiros, 7522 - Pinheiros, São Paulo - SP,04533-085");

        //Alertas
        Alerta alerta1 = new Alerta(1, "Falta de energia na estação Luz, Linha 4-Amarela", 10, "Estação Luz, Linha 4-Amarela", "Falta de energia", LocalDateTime.now(), passageiro1, true, true);


        //Notificações
        Notificacao notificacao1 = new Notificacao(1, "Atraso Linha 4-Amarela", "Operações mais lentas que o normal na linha 4-Amarela, podem haver alguns atrasos", "Atraso", LocalDateTime.now().minusDays(2), false);
        Notificacao notificacao2 = new Notificacao(2, "Atraso Linha 9-Esmeralda", "Operações mais lentas que o normal na linha 9-Esmeralda, podem haver alguns atrasos", "Atraso", LocalDateTime.now().minusDays(1), true);
        Notificacao notificacao3 = new Notificacao(1, "Interrupção Linha 5-Lilás", "As operações na linha 5-Lilás foram interrompidas temporariamente devido à um problema nos trilhos, em breve a situação será normalizada", "Problema nos trilhos", LocalDateTime.now(), false);

        //Adicionando notificações ao feed
        feed.adicionarNotificacao(notificacao1);
        feed.adicionarNotificacao(notificacao2);
        feed.adicionarNotificacao(notificacao3);

        //Adicionando alertas ao feed
        feed.adicionarAlerta(alerta1);

        //Adicionando usuários ao gerenciador
        gerenciador.adicionarUsuario(passageiro1);
        gerenciador.adicionarUsuario(passageiro2);
        gerenciador.adicionarUsuario(funcionario1);
        gerenciador.adicionarUsuario(funcionario2);

        //Adicionando estações às Linhas
        linhaAmarela.adicionarEstacao(estacaoLuz);
        linhaAmarela.adicionarEstacao(estacaoRepublica);
        linhaAmarela.adicionarEstacao(estacaoHigienopolis);
        linhaAmarela.adicionarEstacao(estacaoPaulista);
        linhaAmarela.adicionarEstacao(estacaoOscarFreire);
        linhaAmarela.adicionarEstacao(estacaoFradiqueCoutinho);
        linhaAmarela.adicionarEstacao(estacaoFariaLima);
        linhaAmarela.adicionarEstacao(estacaoPinheiros);
        linhaAmarela.adicionarEstacao(estacaoButanta);
        linhaAmarela.adicionarEstacao(estacaoMorumbi);
        linhaAmarela.adicionarEstacao(estacaoVilaSonia);

        //Lista de alertas da viagem
        List<Alerta> alertasDaViagem = new ArrayList<Alerta>();
        alertasDaViagem.add(alerta1);

        //Viagens
        Viagem viagem1 = new Viagem(30, estacaoLuz, estacaoVilaOlimpia, LocalDateTime.now(), 20, "Bilhete Único - Normal", 4.50, alertasDaViagem);

        //Imprime notificações no feed do passageiro, ordenadas por data e hora
        List<Notificacao> notificacoesOrdenadasPorDataHora = feed.getNotificacoesOrdenadasPorData();
        System.out.println("Olá passageiro, estas são as últimas notificações: ");
        notificacoesOrdenadasPorDataHora.forEach(notificacao ->
                System.out.println(notificacao.getNome() + ": " + notificacao.getMensagem() + "| Data: " + notificacao.getDataHora()));

        System.out.println("\n-----------------------------------------");

        //Passageiro recebe a lista de notificações
        passageiro1.receberListaNotificacoes(feed.getNotificacoesOrdenadasPorData(), passageiro1);
        passageiro2.receberListaNotificacoes(feed.getNotificacoesOrdenadasPorData(), passageiro2);

        System.out.println("\n-----------------------------------------");

        //Imprime a lista de alertas no feed
        List<Alerta> feedDeAlertas = feed.getAlertas();
        System.out.println("Olá, administrador! Aqui estão os últimos alertas: ");
        feedDeAlertas.forEach(alerta ->
                System.out.println(alerta.getDescricaoAlerta()));

        System.out.println("\n-----------------------------------------");

        //Funcionario recebe a lista de alertas
        funcionario1.receberListaDeAlertas(feed.getAlertasOrdenadosPorData(), funcionario1);
        funcionario2.receberListaDeAlertas(feed.getAlertasOrdenadosPorData(), funcionario2);

        System.out.println("\n-----------------------------------------");

        //funcionario recebe um tipo de alerta de acordo com seu cargo
        System.out.println("Alertas de acordo com cada cargo: ");
        gerenciador.enviarAlertaPorFuncionario(3);
        gerenciador.enviarAlertaPorFuncionario(4);

        System.out.println("\n-----------------------------------------");

        //Imprime notificações ordenadas por status, resolvido ou não
        List<Notificacao> notificacoesOrdenadasPorStatus = feed.getNotificacoesOrdenadasPorStatus();
        System.out.println("Notificações listadas por status: ");
        notificacoesOrdenadasPorStatus.forEach(notificacao ->
                System.out.println(notificacao.getNome() + ": " + notificacao.getMensagem() + "| Data: " + notificacao.getDataHora() + "| Resolvido: " + notificacao.isResolvido()));

        System.out.println("\n-----------------------------------------");

        //Imprime a lista de usuários
        List<Usuario> listaDeUsuarios = gerenciador.getListaDeUsuarios();
        System.out.println("Lista de usuários no sistema 'Acessi':");
        listaDeUsuarios.forEach(System.out::println);

        System.out.println("\n-----------------------------------------");

        System.out.println(passageiro1.login("alice@gmail.com", "senha123"));

        System.out.println("\n-----------------------------------------");

        //Imprime a lista de funcionários
        List<Usuario> listaDeFuncionarios = gerenciador.getListaDeFuncionarios();
        System.out.println("Lista de funcionários: ");
        listaDeFuncionarios.forEach(System.out::println);

        System.out.println("\n-----------------------------------------");

        //Imprime a lista de passageiros com as notificações recebidas
        List<Usuario> listaDePassageiros = gerenciador.getListaDePassageiros();
        System.out.println("Lista de passageiros: ");
        listaDePassageiros.forEach(System.out::println);

        System.out.println("\n-----------------------------------------");

        //Imprime funcionário buscado pelo ID
        int idFuncionarioBuscado = 3;
        Optional<Usuario> funcionarioId = gerenciador.getFuncionarioPorId(idFuncionarioBuscado);

        if (funcionarioId.isPresent()) {
            System.out.println("\nFuncionário encontrado pelo ID: " + idFuncionarioBuscado);
            System.out.println(funcionarioId.get());
        } else {
            System.out.println("\nFuncionário não encontrado.");
        }

        System.out.println("\n-----------------------------------------");

        //Imprime passageiro buscado pelo ID
        int idPassageiroBuscado = 1;
        Optional<Usuario> passageiroId = gerenciador.getPassageiroPorId(idPassageiroBuscado);

        if (passageiroId.isPresent()) {
            System.out.println("\nPassageiro encontrado pelo ID: " + idPassageiroBuscado);
            System.out.println(passageiroId.get());
        } else {
            System.out.println("\nPassageiro não encontrado.");
        }

        System.out.println("\n-----------------------------------------");

        //Imprime funcionários com um determinado cargo
        String cargoBuscado = "segurança";
        List<Funcionario> funcionariosPorCargo = gerenciador.getFuncionarioPorCargo(cargoBuscado);
        System.out.println("Lista de funcionários com o cargo de " + cargoBuscado + ":");
        funcionariosPorCargo.forEach(System.out::println);

        System.out.println("\n-----------------------------------------");

        //Imprime a lista de estações de cada linha
        System.out.println(linhaAmarela.getListaDeEstacoes());

        System.out.println("\n-----------------------------------------");

        //Imprime informações da viagem de um passageiro
        System.out.println(viagem1.exibirInformacoesDaViagem());


        System.out.println("\n-----------------------------------------");

        //Problemas relatados em viagem por um Usuario, passageiro ou funcionário
        viagem1.relatarProblemaViagem(alerta1, passageiro1, LocalDateTime.now());

        System.out.println("\n-----------------------------------------");

        //Confirmação do problema, se é verdade ou não, o qual só pode der confirmado por um funcionário de cargo Administrador
        viagem1.confirmarProblema(0, funcionario2);

        System.out.println("\n-----------------------------------------");

        //Calcular e exibir a quantidade de alertas recebidos
        int totalAlertas = feed.contarAlertas();
        System.out.println(totalAlertas);

        //Calcular e exibir a quantidade de notificações recebidas
        int totalNotificacoes = feed.contarNotificacoes();
        System.out.println(totalNotificacoes);

    }
}