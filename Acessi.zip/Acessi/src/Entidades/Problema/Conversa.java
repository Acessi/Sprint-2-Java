package Entidades.Problema;

import java.time.LocalDateTime;
import java.util.Objects;

public class Conversa {
    private String assunto;
    private String modeloLLM;
    private String mensagem;
    private boolean encerrada;
    private LocalDateTime dataHoraMensagem;

    //Constructor vazio
    public Conversa() {
    }

    //Constructor completo
    public Conversa(String assunto, String modeloLLM, String mensagem, boolean encerrada, LocalDateTime dataHoraMensagem) {
        this.assunto = assunto;
        this.modeloLLM = modeloLLM;
        this.mensagem = mensagem;
        this.encerrada = encerrada;
        this.dataHoraMensagem = dataHoraMensagem;
    }

    //Métodos
    public void enviarRespostaDoModeloAoUsuario(String resposta) {
        if (!encerrada) {
            System.out.println("Assunto: " + assunto);
            System.out.println("Modelo LLM: " + modeloLLM);
            System.out.println("Mensagem original: " + mensagem);
            System.out.println("Data e Hora da Mensagem: " + dataHoraMensagem);
            System.out.println("Resposta do modelo: " + resposta);
            // Marcar a conversa como encerrada após enviar a resposta
            this.encerrada = true;
        } else {
            System.out.println("A conversa já está encerrada.");
        }
    }

    public String enviarMensagemAoModelo(String mensagem) {
        // Simulação de uma resposta do modelo LLM
        return "Simulação de resposta do Llama para a mensagem: " + mensagem;
    }

    //Getters e Setters
    public String getAssunto() {
        return assunto;
    }

    public void setAssunto(String assunto) {
        this.assunto = assunto;
    }

    public String getModeloLLM() {
        return modeloLLM;
    }

    public void setModeloLLM(String modeloLLM) {
        this.modeloLLM = modeloLLM;
    }

    public String getMensagem() {
        return mensagem;
    }

    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }

    public boolean isEncerrada() {
        return encerrada;
    }

    public void setEncerrada(boolean encerrada) {
        this.encerrada = encerrada;
    }

    public LocalDateTime getDataHoraMensagem() {
        return dataHoraMensagem;
    }

    public void setDataHoraMensagem(LocalDateTime dataHoraMensagem) {
        this.dataHoraMensagem = dataHoraMensagem;
    }

    //Equals e HashCode
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Conversa conversa = (Conversa) o;
        return isEncerrada() == conversa.isEncerrada() && Objects.equals(getAssunto(), conversa.getAssunto()) && Objects.equals(getModeloLLM(), conversa.getModeloLLM()) && Objects.equals(getMensagem(), conversa.getMensagem()) && Objects.equals(getDataHoraMensagem(), conversa.getDataHoraMensagem());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getAssunto(), getModeloLLM(), getMensagem(), isEncerrada(), getDataHoraMensagem());
    }

    //toString
    @Override
    public String toString() {
        return "Conversa{" +
                "assunto='" + assunto + '\'' +
                ", modeloLLM='" + modeloLLM + '\'' +
                ", mensagem='" + mensagem + '\'' +
                ", encerrada=" + encerrada +
                ", dataHoraMensagem=" + dataHoraMensagem +
                '}';
    }
}
