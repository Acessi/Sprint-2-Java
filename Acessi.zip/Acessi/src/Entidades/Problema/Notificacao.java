package Entidades.Problema;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

public class Notificacao {
    private int identificacao;
    private String nome;
    private String mensagem;
    private String tipo;
    private LocalDateTime dataHora;
    private boolean resolvido;

    //Constructor vazio
    public Notificacao() {
    }

    //Constructor completo
    public Notificacao(int identificacao, String nome, String mensagem, String tipo, LocalDateTime dataHora, boolean resolvido) {
        this.identificacao = identificacao;
        this.nome = nome;
        this.mensagem = mensagem;
        this.tipo = tipo;
        this.dataHora = dataHora;
        this.resolvido = resolvido;
    }


    //Métodos
    public static Notificacao gerarNotificacaoAlerta (Alerta alerta) {
        String mensagem = alerta.getDescricaoAlerta();
        return new Notificacao(alerta.getIdentificacao(), alerta.getDescricao(), mensagem, alerta.getTipo(), LocalDateTime.now(), alerta.isResolvido());
    }

    //Getters e Setters
    public int getIdentificacao() {
        return identificacao;
    }

    public void setIdentificacao(int identificacao) {
        this.identificacao = identificacao;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getMensagem() {
        return mensagem;
    }

    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public LocalDateTime getDataHora() {
        return dataHora;
    }

    public void setDataHora(LocalDateTime dataHora) {
        this.dataHora = dataHora;
    }

    public boolean isResolvido() {
        return resolvido;
    }

    public void setResolvido(boolean resolvido) {
        this.resolvido = resolvido;
    }

    //Equals e HashCode
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Notificacao that = (Notificacao) o;
        return getIdentificacao() == that.getIdentificacao() && isResolvido() == that.isResolvido() && Objects.equals(getNome(), that.getNome()) && Objects.equals(getMensagem(), that.getMensagem()) && Objects.equals(getTipo(), that.getTipo()) && Objects.equals(getDataHora(), that.getDataHora());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getIdentificacao(), getNome(), getMensagem(), getTipo(), getDataHora(), isResolvido());
    }

    //toString
    @Override
    public String toString() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        return "Notificação " +
                "| ID: " + identificacao +
                "| Nome: " + nome + '\'' +
                "| Mensagem: " + mensagem + '\'' +
                "| Tipo: " + tipo + '\'' +
                "| Data e hora: " + dataHora.format(formatter) +
                "| Resolvido: " + resolvido +
                ' ';
    }
}
