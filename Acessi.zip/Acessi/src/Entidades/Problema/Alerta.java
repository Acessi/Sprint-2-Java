package Entidades.Problema;

import Entidades.Pessoa.Funcionario;
import Entidades.Pessoa.Usuario;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

public class Alerta {
    private int identificacao;
    private String descricao;
    private int severidade;
    private String local;
    private String tipo;
    private LocalDateTime dataHora;
    private Usuario relator;
    private boolean confirmado;
    private boolean resolvido;

    //Constructor vazio
    public Alerta() {
    }

    //Constructor completo
    public Alerta(int identificacao, String descricao, int severidade, String local, String tipo, LocalDateTime dataHora, Usuario relator, boolean confirmado, boolean resolvido) {
        this.identificacao = identificacao;
        this.descricao = descricao;
        this.severidade = severidade;
        this.local = local;
        this.tipo = tipo;
        this.dataHora = dataHora;
        this.relator = relator;
        this.confirmado = confirmado;
        this.resolvido = resolvido;
    }

    //Métodos
    public void confirmar() {
        this.confirmado = true;
    }

    public String getDescricaoAlerta() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        return String.format("Alerta ID: %d\nDescrição: %s\nSeveridade: %s\nLocal: %s\nData e hora: %s\nConfirmado: %s\nResolvido: %s",
                identificacao,descricao,severidade,local,dataHora.format(formatter), confirmado, resolvido);
    }

    public Notificacao enviarAlerta(int identificacao, Funcionario funcionario) {
        String mensagem = getDescricaoAlerta();
        LocalDateTime agora = LocalDateTime.now();
        return new Notificacao(identificacao, funcionario.getNome(), mensagem, tipo, agora, false);
    }

    public static String alertaPorCargo(String cargo) {
        switch (cargo.toLowerCase()) {
            case "maquinista":
                return "Por favor, verifique o sistema de segurança do trem.";
            case "zelador":
                return "Necessidade de inspeção e limpeza na estação atual.";
            case "segurança":
                return "Checar vigilância nas estações e vagões.";
            default:
                return "Cargo não reconhecido. Entre em contato com o supervisor.";
        }
    }

    //Getters e Setters
    public int getIdentificacao() {
        return identificacao;
    }

    public void setIdentificacao(int identificacao) {
        this.identificacao = identificacao;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public int getSeveridade() {
        return severidade;
    }

    public void setSeveridade(int severidade) {
        this.severidade = severidade;
    }

    public String getLocal() {
        return local;
    }

    public void setLocal(String local) {
        this.local = local;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public LocalDateTime getDataHora() {
        return dataHora;
    }

    public void setDataHora(LocalDateTime dataHora) {
        this.dataHora = dataHora;
    }

    public Usuario getRelator() {
        return relator;
    }

    public void setRelator(Usuario relator) {
        this.relator = relator;
    }

    public boolean isConfirmado() {
        return confirmado;
    }

    public void setConfirmado(boolean confirmado) {
        this.confirmado = confirmado;
    }

    public boolean isResolvido() {
        return resolvido;
    }

    public void setResolvido(boolean resolvido) {
        this.resolvido = resolvido;
    }

    //Equals e HashCode
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Alerta alerta = (Alerta) o;
        return identificacao == alerta.identificacao && severidade == alerta.severidade && confirmado == alerta.confirmado && resolvido == alerta.resolvido && Objects.equals(descricao, alerta.descricao) && Objects.equals(local, alerta.local) && Objects.equals(tipo, alerta.tipo) && Objects.equals(dataHora, alerta.dataHora) && Objects.equals(relator, alerta.relator);
    }

    @Override
    public int hashCode() {
        return Objects.hash(identificacao, descricao, severidade, local, tipo, dataHora, relator, confirmado, resolvido);
    }

    //toString
    @Override
    public String toString() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        return "Alerta " +
                "| ID: " + identificacao +
                "| Descrição: " + descricao + '\'' +
                "| Severidade: " + severidade + '\'' +
                "| Local: " + local + '\'' +
                "| Tipo: " + tipo + '\'' +
                "| Data e hora: " + dataHora.format(formatter) +
                "| Relatado por: " + relator +
                "| Confirmado: " + confirmado +
                "| Resolvido: " + resolvido +
                ' ';
    }
}
