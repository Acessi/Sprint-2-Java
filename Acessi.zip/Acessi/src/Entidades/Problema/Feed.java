package Entidades.Problema;

import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class Feed {
    private List<Notificacao> notificacoes;
    private List<Alerta> alertas;

    //Constructor vazio
    public Feed() {
    }

    //Constructor completo
    public Feed(List<Notificacao> notificacoes, List<Alerta> alertas) {
        this.notificacoes = notificacoes;
        this.alertas = alertas;
    }

    //Métodos
    public void adicionarNotificacao(Notificacao notificacao) {
        notificacoes.add(notificacao);
    }

    public void removerNotificacao(Notificacao notificacao) {
        notificacoes.remove(notificacao);
    }

    public void adicionarAlerta(Alerta alerta) {
        alertas.add(alerta);
    }

    public void removerAlerta(Alerta alerta) {
        alertas.remove(alerta);
    }

    public int contarAlertas() {
        System.out.println("Total de alertas recebidos no sistema: ");
        return alertas.size();
    }

    public int contarNotificacoes() {
        System.out.println("Total de notificações recebidas no sistema: ");
        return notificacoes.size();
    }

    public List<Notificacao> getNotificacoesOrdenadasPorData() {
        return this.notificacoes.stream()
                .sorted((n1, n2) -> n2.getDataHora().compareTo(n1.getDataHora()))
                .collect(Collectors.toList());
    }

    public List<Notificacao> getNotificacoesOrdenadasPorStatus() {
        return this.notificacoes.stream()
                .sorted((n1, n2) -> Boolean.compare(n1.isResolvido(), n2.isResolvido()))
                .collect(Collectors.toList());
    }

    public List<Alerta> getAlertasOrdenadosPorTipo(){
        return this.alertas.stream()
                .sorted(Comparator.comparing(Alerta::getTipo))
                .collect(Collectors.toList());
    }

    public List<Alerta> getAlertasOrdenadosPorData() {
        return this.alertas.stream()
                .sorted((a1, a2) -> a2.getDataHora().compareTo(a1.getDataHora()))
                .collect(Collectors.toList());
    }

    public List<Alerta> getAlertasOrdenadosPorSeveridade() {
        return alertas.stream()
                .sorted((a1, a2) -> Integer.compare(a1.getSeveridade(), a2.getSeveridade()))
                .collect(Collectors.toList());
    }

    //Getters e Setters
    public List<Notificacao> getNotificacoes() {
        return notificacoes;
    }

    public void setNotificacoes(List<Notificacao> notificacoes) {
        this.notificacoes = notificacoes;
    }

    public List<Alerta> getAlertas() {
        return alertas;
    }

    public void setAlertas(List<Alerta> alertas) {
        this.alertas = alertas;
    }

    //Equals e HashCode
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Feed feed = (Feed) o;
        return Objects.equals(getNotificacoes(), feed.getNotificacoes()) && Objects.equals(getAlertas(), feed.getAlertas());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getNotificacoes(), getAlertas());
    }

    //toString
    @Override
    public String toString() {
        return "Feed{" +
                "notificacoes=" + notificacoes +
                ", alertas=" + alertas +
                '}';
    }
}
