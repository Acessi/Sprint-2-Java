package Entidades.Pessoa;

import java.util.Objects;
import java.util.Random;

public class Usuario {
    private int identificaco;
    private String nome;
    private String email;
    private String senha;
    private String tipo;
    private boolean logado;
    private String codigoRecuperacao;

    //Métodos
    public boolean login(String email, String senha) {
        System.out.println("Usuário " + nome + "| ID: " + identificaco + "| Logado: ");
        if (this.email.equals(email) && this.senha.equals(senha)) {
            this.logado = true;
            return true;
        }
        return false;
    }

    public void logout() {
        this.logado = false;
    }

    public void gerarCodigoRecuperacao() {
        Random rand = new Random();
        this.codigoRecuperacao = String.format("%06d", rand.nextInt(1000000));
        // Simula o envio do código de recuperação para o e-mail do usuário
        System.out.println("Código de recuperação enviado para " + this.email + ": " + this.codigoRecuperacao);
        // Aqui você integraria um serviço de e-mail para enviar o código real para o e-mail do usuário
    }

    public boolean recuperarSenha(String codigo) {
        if (this.codigoRecuperacao != null && this.codigoRecuperacao.equals(codigo)) {
            // Simula o envio da senha para o e-mail do usuário
            System.out.println("Sua senha é: " + this.senha + ". Enviada para o e-mail: " + this.email);
            // Invalida o código após a recuperação
            this.codigoRecuperacao = null;
            return true;
        }
        return false;
    }

    public boolean trocarSenha(String codigo, String novaSenha) {
        if (this.codigoRecuperacao != null && this.codigoRecuperacao.equals(codigo)) {
            this.senha = novaSenha;
            System.out.println("Senha trocada com sucesso!");
            this.codigoRecuperacao = null;
            return true;
        }
        System.out.println("Código de recuperação inválido!");
        return false;
    }

    //Constructor vazio
    public Usuario() {
    }

    //Constructor completo
    public Usuario(int identificaco, String nome, String email, String senha, String tipo) {
        this.identificaco = identificaco;
        this.nome = nome;
        this.email = email;
        this.senha = senha;
        this.tipo = tipo;
        this.logado = false;
        this.codigoRecuperacao = null;
    }

    //Getters e setters
    public int getIdentificaco() {
        return identificaco;
    }

    public void setIdentificaco(int identificaco) {
        this.identificaco = identificaco;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public boolean isLogado() {
        return logado;
    }

    public void setLogado(boolean logado) {
        this.logado = logado;
    }

    public String getCodigoRecuperacao() {
        return codigoRecuperacao;
    }

    public void setCodigoRecuperacao(String codigoRecuperacao) {
        this.codigoRecuperacao = codigoRecuperacao;
    }

    //Equalls e HashCode
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Usuario usuario = (Usuario) o;
        return getIdentificaco() == usuario.getIdentificaco() && isLogado() == usuario.isLogado() && Objects.equals(getNome(), usuario.getNome()) && Objects.equals(getEmail(), usuario.getEmail()) && Objects.equals(getSenha(), usuario.getSenha()) && Objects.equals(getTipo(), usuario.getTipo()) && Objects.equals(getCodigoRecuperacao(), usuario.getCodigoRecuperacao());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getIdentificaco(), getNome(), getEmail(), getSenha(), getTipo(), isLogado(), getCodigoRecuperacao());
    }

    //toString
    @Override
    public String toString() {
        return "Usuario " +
                "| ID: " + identificaco +
                "| Nome: " + nome + '\'' +
                "| E-mail: " + email + '\'' +
                "| Senha: " + senha + '\'' +
                "| Tipo: " + tipo + '\'' +
                "| Logado: " + logado +
                ' ';
    }
}
