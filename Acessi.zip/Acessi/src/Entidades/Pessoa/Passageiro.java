package Entidades.Pessoa;

import Entidades.Problema.Notificacao;

import java.util.List;
import java.util.Objects;

public class Passageiro extends Usuario{
    private int idPassageiro;
    private List<Notificacao> notificacoes;

    //Constructor vazio
    public Passageiro() {
    }

    //Constructor completo
    public Passageiro(int identificaco, String nome, String email, String senha, String tipo, int idPassageiro, List<Notificacao> notificacoesRecebidas) {
        super(identificaco, nome, email, senha, tipo);
        this.idPassageiro = idPassageiro;
        this.notificacoes = notificacoesRecebidas;
    }

    //Metodos
    public void receberListaNotificacoes(List<Notificacao> notificacoes, Passageiro passageiro) {
        this.notificacoes.addAll(notificacoes);
        System.out.println("\nPassageiro(a) " + passageiro.getNome() + "\nNotificações recebidas: \n" + notificacoes);
    }

    //Getters e Setters
    public int getIdPassageiro() {
        return idPassageiro;
    }

    public void setIdPassageiro(int idPassageiro) {
        this.idPassageiro = idPassageiro;
    }

    public List<Notificacao> getNotificacoes() {
        return notificacoes;
    }

    public void setNotificacoes(List<Notificacao> notificacoes) {
        this.notificacoes = notificacoes;
    }

    //Equalls e HashCode
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Passageiro that = (Passageiro) o;
        return getIdPassageiro() == that.getIdPassageiro() && Objects.equals(getNotificacoes(), that.getNotificacoes());
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), getIdPassageiro(), getNotificacoes());
    }

    //toString
    @Override
    public String toString() {
        return "Passageiro " +
                "| ID Passageiro: " + idPassageiro +
                " " + super.toString();
    }
}
