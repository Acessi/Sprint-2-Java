package Entidades.Pessoa;

import Entidades.Problema.Alerta;

import java.util.*;
import java.util.stream.Collectors;

public class GerenciadorDeUsuario {
    private ArrayList<Usuario> usuarios;

    //Constructor vazio
    public GerenciadorDeUsuario() {
    }

    //Constructor completo
    public GerenciadorDeUsuario(ArrayList<Usuario> usuarios) {
        this.usuarios = usuarios;
    }

    //Métodos
    public boolean cadastrarUsuario(int identificacao, String nome, String email, String senha, String tipo) {
        for (Usuario usuario : usuarios) {
            if (usuario.getEmail().equals(email)) {
                System.out.println("Usuário já cadastrado com este e-mail.");
                return false;
            }
        }
        Usuario novoUsuario = new Usuario(identificacao, nome, email, senha, tipo);
        usuarios.add(novoUsuario);
        System.out.println("Usuário cadastrado com sucesso!");
        return true;
    }

    public void adicionarUsuario(Usuario usuario){
        usuarios.add(usuario);
    }

    public void removerUsuario(Usuario usuario){
        usuarios.remove(usuario);
    }

    public List<Usuario> getListaDeUsuarios() {
        return usuarios.stream()
                .distinct()
                .collect(Collectors.toList());
    }

    public List<Usuario> getListaDeFuncionarios(){
        return usuarios.stream()
                .filter(usuario -> usuario.getTipo().equalsIgnoreCase("Funcionário"))
                .distinct()
                .collect(Collectors.toList());
    }

    public Optional<Usuario> getFuncionarioPorId(int id) {
        return usuarios.stream()
                .filter(usuario -> usuario.getTipo().equalsIgnoreCase("Funcionário")
                        && usuario.getIdentificaco() == id)
                .findFirst();
    }

    public List<Funcionario> getFuncionarioPorCargo(String cargo) {
        return usuarios.stream()
                .filter(usuario -> usuario instanceof Funcionario)
                .map(usuario -> (Funcionario) usuario)
                .filter(funcionario -> funcionario.getCargo().equalsIgnoreCase(cargo))
                .distinct()
                .collect(Collectors.toList());
    }

    public List<Usuario> getListaDePassageiros(){
        return usuarios.stream()
                .filter(usuario -> usuario.getTipo().equalsIgnoreCase("Passageiro"))
                .distinct()
                .collect(Collectors.toList());
    }

    public Optional<Usuario> getPassageiroPorId(int id) {
        return usuarios.stream()
                .filter(usuario -> usuario.getTipo().equalsIgnoreCase("Passageiro")
                        && usuario.getIdentificaco() == id)
                .findFirst();
    }

    public void enviarAlertaPorFuncionario(int id) {
        Optional<Usuario> usuarioOptional = usuarios.stream()
                .filter(usuario -> usuario.getIdentificaco() == id && usuario instanceof Funcionario)
                .findFirst();

        if (usuarioOptional.isPresent()) {
            Funcionario funcionario = (Funcionario) usuarioOptional.get();
            String alerta = Alerta.alertaPorCargo(funcionario.getCargo());
            System.out.println("Alerta para funcionário(a) " + funcionario.getNome() +
                    " (ID: " + funcionario.getIdFuncionario() + "): " + alerta);
        } else {
            System.out.println("Funcionário com ID " + id + " não encontrado.");
        }
    }

    //Getters e Setters
    public ArrayList<Usuario> getUsuarios() {
        return usuarios;
    }

    public void setUsuarios(ArrayList<Usuario> usuarios) {
        this.usuarios = usuarios;
    }

    //Equals e HashCode
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        GerenciadorDeUsuario that = (GerenciadorDeUsuario) o;
        return Objects.equals(getUsuarios(), that.getUsuarios());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getUsuarios());
    }

    //toString
    @Override
    public String toString() {
        return "GerenciadorDeUsuario{" +
                "usuarios=" + usuarios +
                '}';
    }
}
