package Entidades.Pessoa;

import Entidades.Problema.Alerta;

import java.util.List;
import java.util.Objects;

public class Funcionario extends Usuario{
    private int idFuncionario;
    private String cargo;
    private List<Alerta> alertas;

    //Constructor vazio
    public Funcionario() {
    }

    //Constructor completo
    public Funcionario(int identificaco, String nome, String email, String senha, String tipo, int idFuncionario, String cargo, List<Alerta> alertas) {
        super(identificaco, nome, email, senha, tipo);
        this.idFuncionario = idFuncionario;
        this.cargo = cargo;
        this.alertas = alertas;
    }

    //Métodos
    public void receberListaDeAlertas(List<Alerta> alertas, Funcionario funcionario) {
        this.alertas.addAll(alertas);
        System.out.println("\nFuncionário(a) " + funcionario.getNome() + "\nAlertas recebidos: \n" + alertas);
    }

    public boolean isAdministrador() {
        return "Administrador".equalsIgnoreCase(cargo);
    }


    //Getters e Setters
    public int getIdFuncionario() {
        return idFuncionario;
    }

    public void setIdFuncionario(int idFuncionario) {
        this.idFuncionario = idFuncionario;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public List<Alerta> getAlertas() {
        return alertas;
    }

    public void setAlertas(List<Alerta> alertas) {
        this.alertas = alertas;
    }

    //Equalls e HashCode
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Funcionario that = (Funcionario) o;
        return getIdFuncionario() == that.getIdFuncionario() && Objects.equals(getCargo(), that.getCargo()) && Objects.equals(getAlertas(), that.getAlertas());
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), getIdFuncionario(), getCargo(), getAlertas());
    }

    //toString
    @Override
    public String toString() {
        return "Funcionario " +
                "| ID Funcionario: " + idFuncionario +
                "| Cargo: " + cargo + '\'' +
                " " + super.toString();
    }
}
