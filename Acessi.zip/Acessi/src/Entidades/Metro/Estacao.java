package Entidades.Metro;

import java.util.Objects;

public class Estacao {
    private String nome;
    private int capacidadeMaxima;
    private int capacidadeAtual;
    private String localizacao;

    //Constructor vazio
    public Estacao() {
    }

    //Constructor completo
    public Estacao(String nome, int capacidadeMaxima, int capacidadeAtual, String localizacao) {
        this.nome = nome;
        this.capacidadeMaxima = capacidadeMaxima;
        this.capacidadeAtual = capacidadeAtual;
        this.localizacao = localizacao;
    }

    //Métodos

    //Getters e Setters
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getCapacidadeMaxima() {
        return capacidadeMaxima;
    }

    public void setCapacidadeMaxima(int capacidadeMaxima) {
        this.capacidadeMaxima = capacidadeMaxima;
    }

    public int getCapacidadeAtual() {
        return capacidadeAtual;
    }

    public void setCapacidadeAtual(int capacidadeAtual) {
        this.capacidadeAtual = capacidadeAtual;
    }

    public String getLocalizacao() {
        return localizacao;
    }

    public void setLocalizacao(String localizacao) {
        this.localizacao = localizacao;
    }

    //Equals e HashCode
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Estacao estacao = (Estacao) o;
        return getCapacidadeMaxima() == estacao.getCapacidadeMaxima() && getCapacidadeAtual() == estacao.getCapacidadeAtual() && Objects.equals(getNome(), estacao.getNome()) && Objects.equals(getLocalizacao(), estacao.getLocalizacao());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getNome(), getCapacidadeMaxima(), getCapacidadeAtual(), getLocalizacao());
    }

    //toString
    @Override
    public String toString() {
        return "Estacao{" +
                "nome='" + nome + '\'' +
                ", capacidadeMaxima=" + capacidadeMaxima +
                ", capacidadeAtual=" + capacidadeAtual +
                ", localizacao='" + localizacao + '\'' +
                '}';
    }
}
