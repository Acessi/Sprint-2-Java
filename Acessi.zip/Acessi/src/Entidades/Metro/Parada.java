package Entidades.Metro;

import java.util.Objects;

public class Parada {
    private String plataforma;
    private String nomeEstacao;
    private String nomeLinha;

    //Constructor vazio
    public Parada() {
    }

    //Constructor completo
    public Parada(String plataforma, String nomeEstacao, String nomeLinha) {
        this.plataforma = plataforma;
        this.nomeEstacao = nomeEstacao;
        this.nomeLinha = nomeLinha;
    }

    //Métodos

    //Getters e Setters
    public String getPlataforma() {
        return plataforma;
    }

    public void setPlataforma(String plataforma) {
        this.plataforma = plataforma;
    }

    public String getNomeEstacao() {
        return nomeEstacao;
    }

    public void setNomeEstacao(String nomeEstacao) {
        this.nomeEstacao = nomeEstacao;
    }

    public String getNomeLinha() {
        return nomeLinha;
    }

    public void setNomeLinha(String nomeLinha) {
        this.nomeLinha = nomeLinha;
    }

    //Equals e HashCode
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Parada parada = (Parada) o;
        return Objects.equals(getPlataforma(), parada.getPlataforma()) && Objects.equals(getNomeEstacao(), parada.getNomeEstacao()) && Objects.equals(getNomeLinha(), parada.getNomeLinha());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getPlataforma(), getNomeEstacao(), getNomeLinha());
    }

    //toString
    @Override
    public String toString() {
        return "Parada{" +
                "plataforma='" + plataforma + '\'' +
                ", nomeEstacao='" + nomeEstacao + '\'' +
                ", nomeLinha='" + nomeLinha + '\'' +
                '}';
    }
}
