package Entidades.Metro;

import java.time.LocalTime;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class Linha {
    private String nome;
    private LocalTime horarioAbertura;
    private LocalTime horarioFechamento;
    private String cor;
    private String numero;
    private List<Estacao> estacoes;

    //Constructor vazio
    public Linha() {
    }

    //Constructor completo
    public Linha(String nome, LocalTime horarioAbertura, LocalTime horarioFechamento, String cor, String numero, List<Estacao> estacoes) {
        this.nome = nome;
        this.horarioAbertura = horarioAbertura;
        this.horarioFechamento = horarioFechamento;
        this.cor = cor;
        this.numero = numero;
        this.estacoes = estacoes;
    }

    //Métodos
    public void adicionarEstacao(Estacao estacao) {
        estacoes.add(estacao);
    }

    public String getListaDeEstacoes (){
        System.out.println("Estações da " + getNome() + ":");
        return estacoes.stream()
                .map(Estacao::getNome)
                .collect(Collectors.joining(", "));
    }

    //Getters e Setters
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public LocalTime getHorarioAbertura() {
        return horarioAbertura;
    }

    public void setHorarioAbertura(LocalTime horarioAbertura) {
        this.horarioAbertura = horarioAbertura;
    }

    public LocalTime getHorarioFechamento() {
        return horarioFechamento;
    }

    public void setHorarioFechamento(LocalTime horarioFechamento) {
        this.horarioFechamento = horarioFechamento;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public List<Estacao> getEstacoes() {
        return estacoes;
    }

    public void setEstacoes(List<Estacao> estacoes) {
        this.estacoes = estacoes;
    }


    //Equals e HashCode
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Linha linha = (Linha) o;
        return Objects.equals(getNome(), linha.getNome()) && Objects.equals(getHorarioAbertura(), linha.getHorarioAbertura()) && Objects.equals(getHorarioFechamento(), linha.getHorarioFechamento()) && Objects.equals(getCor(), linha.getCor()) && Objects.equals(getNumero(), linha.getNumero()) && Objects.equals(getEstacoes(), linha.getEstacoes());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getNome(), getHorarioAbertura(), getHorarioFechamento(), getCor(), getNumero(), getEstacoes());
    }

    //toString
    @Override
    public String toString() {
        return "Linha{" +
                "nome='" + nome + '\'' +
                ", horarioAbertura=" + horarioAbertura +
                ", horarioFechamento=" + horarioFechamento +
                ", cor='" + cor + '\'' +
                ", numero='" + numero + '\'' +
                ", estacoes=" + estacoes +
                '}';
    }
}
