package Entidades.Metro;

import java.util.Objects;

public class Vagao {
    private String nome;
    private int capacidadeMaxima;
    private int capacidadeAtual;

    //Constructor vazio
    public Vagao() {
    }

    //Constructor completo
    public Vagao(String nome, int capacidadeMaxima, int capacidadeAtual) {
        this.nome = nome;
        this.capacidadeMaxima = capacidadeMaxima;
        this.capacidadeAtual = capacidadeAtual;
    }

    //Métodos

    //Getters e Setters
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getCapacidadeMaxima() {
        return capacidadeMaxima;
    }

    public void setCapacidadeMaxima(int capacidadeMaxima) {
        this.capacidadeMaxima = capacidadeMaxima;
    }

    public int getCapacidadeAtual() {
        return capacidadeAtual;
    }

    public void setCapacidadeAtual(int capacidadeAtual) {
        this.capacidadeAtual = capacidadeAtual;
    }

    //Equals e HashCode
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Vagao vagao = (Vagao) o;
        return getCapacidadeMaxima() == vagao.getCapacidadeMaxima() && getCapacidadeAtual() == vagao.getCapacidadeAtual() && Objects.equals(getNome(), vagao.getNome());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getNome(), getCapacidadeMaxima(), getCapacidadeAtual());
    }

    //toString
    @Override
    public String toString() {
        return "Vagao{" +
                "nome='" + nome + '\'' +
                ", capacidadeMaxima=" + capacidadeMaxima +
                ", capacidadeAtual=" + capacidadeAtual +
                '}';
    }
}
