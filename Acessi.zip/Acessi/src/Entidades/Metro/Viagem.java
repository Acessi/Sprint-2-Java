package Entidades.Metro;

import Entidades.Pessoa.Funcionario;
import Entidades.Pessoa.Passageiro;
import Entidades.Pessoa.Usuario;
import Entidades.Problema.Alerta;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Objects;

public class Viagem {
    private int duracao;
    private Estacao estacaoOrigem;
    private Estacao estacaoDestino;
    private LocalDateTime dataHora;
    private int numeroParadas;
    private String tipoPassagem;
    private double tarifaPassagem;
    private List<Alerta> problemas;

    //Constructor vazio
    public Viagem() {
    }

    //Constructor completo
    public Viagem(int duracao, Estacao estacaoOrigem, Estacao estacaoDestino, LocalDateTime dataHora, int numeroParadas, String tipoPassagem, double tarifaPassagem, List<Alerta> problemas) {
        this.duracao = duracao;
        this.estacaoOrigem = estacaoOrigem;
        this.estacaoDestino = estacaoDestino;
        this.dataHora = dataHora;
        this.numeroParadas = numeroParadas;
        this.tipoPassagem = tipoPassagem;
        this.tarifaPassagem = tarifaPassagem;
        this.problemas = problemas;
    }

    //Métodos
    public void relatarProblemaViagem(Alerta alerta, Usuario relator, LocalDateTime dataHora) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        System.out.println("Problema relatado pelo " + relator.getTipo() + " " + relator.getNome() + ": " + alerta.getDescricao() + "| Horário: " + dataHora.format(formatter));
    }

    public void confirmarProblema(int problemaIndex, Funcionario funcionario) {
        if (funcionario.isAdministrador() && problemaIndex >= 0 && problemaIndex < problemas.size()) {
            Alerta problema = problemas.get(problemaIndex);
            problema.confirmar();
            System.out.println("Problema confirmado: " + problema.getDescricao());
        } else {
            System.out.println("Usuário não autorizado ou problema inválido");
        }
    }

    public String exibirInformacoesDaViagem() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        return "Informações da viagem:\n" +
                "Duração: " + duracao + " minutos\n" +
                "Estação de origem: " + estacaoOrigem.getNome() + "\n" +
                "Estação de destino: " + estacaoDestino.getNome() + "\n" +
                "Data e hora: " + dataHora.format(formatter) + "\n" +
                "Número de paradas: " + numeroParadas + "\n" +
                "Tipo de passagem: " + tipoPassagem + "\n" +
                "Tarifa da passagem: R$ " + tarifaPassagem + "\n" +
                "Problema na viagem: " + problemas;
    }


    //Getters e Setters
    public int getDuracao() {
        return duracao;
    }

    public void setDuracao(int duracao) {
        this.duracao = duracao;
    }

    public Estacao getEstacaoOrigem() {
        return estacaoOrigem;
    }

    public void setEstacaoOrigem(Estacao estacaoOrigem) {
        this.estacaoOrigem = estacaoOrigem;
    }

    public Estacao getEstacaoDestino() {
        return estacaoDestino;
    }

    public void setEstacaoDestino(Estacao estacaoDestino) {
        this.estacaoDestino = estacaoDestino;
    }

    public LocalDateTime getDataHora() {
        return dataHora;
    }

    public void setDataHora(LocalDateTime dataHora) {
        this.dataHora = dataHora;
    }

    public int getNumeroParadas() {
        return numeroParadas;
    }

    public void setNumeroParadas(int numeroParadas) {
        this.numeroParadas = numeroParadas;
    }

    public String getTipoPassagem() {
        return tipoPassagem;
    }

    public void setTipoPassagem(String tipoPassagem) {
        this.tipoPassagem = tipoPassagem;
    }

    public double getTarifaPassagem() {
        return tarifaPassagem;
    }

    public void setTarifaPassagem(double tarifaPassagem) {
        this.tarifaPassagem = tarifaPassagem;
    }

    public List<Alerta> getProblemas() {
        return problemas;
    }

    public void setProblemas(List<Alerta> problemas) {
        this.problemas = problemas;
    }

    //Equals e HashCode
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Viagem viagem = (Viagem) o;
        return getDuracao() == viagem.getDuracao() && getNumeroParadas() == viagem.getNumeroParadas() && Double.compare(getTarifaPassagem(), viagem.getTarifaPassagem()) == 0 && Objects.equals(getEstacaoOrigem(), viagem.getEstacaoOrigem()) && Objects.equals(getEstacaoDestino(), viagem.getEstacaoDestino()) && Objects.equals(getDataHora(), viagem.getDataHora()) && Objects.equals(getTipoPassagem(), viagem.getTipoPassagem()) && Objects.equals(getProblemas(), viagem.getProblemas());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getDuracao(), getEstacaoOrigem(), getEstacaoDestino(), getDataHora(), getNumeroParadas(), getTipoPassagem(), getTarifaPassagem(), getProblemas());
    }

    //toString
    @Override
    public String toString() {
        return "Viagem{" +
                "duracao=" + duracao +
                ", estacaoOrigem=" + estacaoOrigem +
                ", estacaoDestino=" + estacaoDestino +
                ", dataHora=" + dataHora +
                ", numeroParadas=" + numeroParadas +
                ", tipoPassagem='" + tipoPassagem + '\'' +
                ", tarifaPassagem=" + tarifaPassagem +
                ", problemas=" + problemas +
                '}';
    }
}
