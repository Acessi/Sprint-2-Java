package Entidades.Metro;

import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class Trem {
    private int id;
    private List<Vagao> vagoes;
    private String origem;
    private String destino;
    private int numeroParadas;
    private int capacidadeMaxima;
    private int capacidadeAtual;
    private boolean operando;

    //Constructor vazio
    public Trem() {
    }

    //Constructor completo
    public Trem(int id, List<Vagao> vagoes, String origem, String destino, int numeroParadas, int capacidadeMaxima, int capacidadeAtual, boolean operando) {
        this.id = id;
        this.vagoes = vagoes;
        this.origem = origem;
        this.destino = destino;
        this.numeroParadas = numeroParadas;
        this.capacidadeMaxima = capacidadeMaxima;
        this.capacidadeAtual = capacidadeAtual;
        this.operando = operando;
    }

    //Métodos
    public List<Vagao> getVagaoPorNome(){
        return vagoes.stream()
                .sorted(Comparator.comparing(Vagao::getNome))
                .collect(Collectors.toList());
    }

    //Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public List<Vagao> getVagoes() {
        return vagoes;
    }

    public void setVagoes(List<Vagao> vagoes) {
        this.vagoes = vagoes;
    }

    public String getOrigem() {
        return origem;
    }

    public void setOrigem(String origem) {
        this.origem = origem;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public int getNumeroParadas() {
        return numeroParadas;
    }

    public void setNumeroParadas(int numeroParadas) {
        this.numeroParadas = numeroParadas;
    }

    public int getCapacidadeMaxima() {
        return capacidadeMaxima;
    }

    public void setCapacidadeMaxima(int capacidadeMaxima) {
        this.capacidadeMaxima = capacidadeMaxima;
    }

    public int getCapacidadeAtual() {
        return capacidadeAtual;
    }

    public void setCapacidadeAtual(int capacidadeAtual) {
        this.capacidadeAtual = capacidadeAtual;
    }

    public boolean isOperando() {
        return operando;
    }

    public void setOperando(boolean operando) {
        this.operando = operando;
    }

    //Equals e HashCode
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Trem trem = (Trem) o;
        return getId() == trem.getId() && getNumeroParadas() == trem.getNumeroParadas() && getCapacidadeMaxima() == trem.getCapacidadeMaxima() && getCapacidadeAtual() == trem.getCapacidadeAtual() && isOperando() == trem.isOperando() && Objects.equals(getVagoes(), trem.getVagoes()) && Objects.equals(getOrigem(), trem.getOrigem()) && Objects.equals(getDestino(), trem.getDestino());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getVagoes(), getOrigem(), getDestino(), getNumeroParadas(), getCapacidadeMaxima(), getCapacidadeAtual(), isOperando());
    }

    //toString
    @Override
    public String toString() {
        return "Trem{" +
                "id=" + id +
                ", vagoes=" + vagoes +
                ", origem='" + origem + '\'' +
                ", destino='" + destino + '\'' +
                ", numeroParadas=" + numeroParadas +
                ", capacidadeMaxima=" + capacidadeMaxima +
                ", capacidadeAtual=" + capacidadeAtual +
                ", operando=" + operando +
                '}';
    }
}
